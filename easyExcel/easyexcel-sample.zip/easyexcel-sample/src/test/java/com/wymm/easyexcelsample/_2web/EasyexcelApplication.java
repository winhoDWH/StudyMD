package com.wymm.easyexcelsample._2web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EasyexcelApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(EasyexcelApplication.class, args);
    }
}
