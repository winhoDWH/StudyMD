package com.wymm.easyexcelsample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EasyexcelSampleApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(EasyexcelSampleApplication.class, args);
    }
    
}
