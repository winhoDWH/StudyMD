package com.wymm.easyexcelsample.excel.merger;

import lombok.Data;

@Data
public class Book {
    
    private Long bookId;
    
    private String bookName;
    
    private String author;
}
